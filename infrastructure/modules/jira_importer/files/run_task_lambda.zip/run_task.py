import boto3


def handler(event,context):
  client = boto3.client('ecs')
  response = client.run_task(
  cluster='arn:aws:ecs:us-east-1:072502627258:cluster/jira-importer-fargate', # name of the cluster
  launchType = 'FARGATE',
  taskDefinition='jira_import',
  count = 1,
  platformVersion='LATEST',
  networkConfiguration={
        'awsvpcConfiguration': {
            'subnets': ['subnet-46c12521'],
            'securityGroups': ['sg-c041a589'],
            'assignPublicIp': 'DISABLED'
        }
    })

  return str(response)
